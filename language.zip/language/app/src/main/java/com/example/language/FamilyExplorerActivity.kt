package com.example.language

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton

/**
 * SCREEN 6: FamilyExplorerActivity
 */
class FamilyExplorerActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_family_explorer)

        val root = findViewById<android.view.View>(R.id.family_root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        findViewById<MaterialButton>(R.id.btn_book_family)?.setOnClickListener {
            startActivity(Intent(this, BookingQuotationActivity::class.java))
        }

        findViewById<MaterialButton>(R.id.btn_back_family)?.setOnClickListener {
            finish()
        }
    }
}
