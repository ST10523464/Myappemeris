package com.example.language

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/**
 * SplashActivity
 * ============================================================================
 * Launcher activity for the application.
 *
 * Responsibilities:
 * - Displays the "Explore The Nature" brand badge splash screen.
 * - Handles edge-to-edge window insets padding.
 * - Applies a subtle entrance animation (scale and alpha fade) on the logo.
 * - Automatically transitions to [MainActivity] after a brief delay.
 * ============================================================================
 */
class SplashActivity : AppCompatActivity() {

    private val splashDelayMs = 2500L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Enable edge-to-edge layout display
        enableEdgeToEdge()

        setContentView(R.layout.activity_splash)

        // Adjust layout padding based on system bars insets
        val rootLayout = findViewById<android.view.View>(R.id.splash_root)
        ViewCompat.setOnApplyWindowInsetsListener(rootLayout) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Animate the brand logo entry
        animateLogo()

        // Schedule transition to MainActivity
        Handler(Looper.getMainLooper()).postDelayed({
            navigateToMainActivity()
        }, splashDelayMs)
    }

    /**
     * Applies a subtle zoom and alpha animation to the splash screen logo.
     */
    private fun animateLogo() {
        val logoImageView = findViewById<ImageView>(R.id.iv_splash_logo)
        logoImageView.alpha = 0f
        logoImageView.scaleX = 0.8f
        logoImageView.scaleY = 0.8f

        logoImageView.animate()
            .alpha(1f)
            .scaleX(1.0f)
            .scaleY(1.0f)
            .setDuration(1000)
            .setInterpolator(AccelerateDecelerateInterpolator())
            .start()
    }

    /**
     * Navigates from SplashActivity to MainActivity and finishes current activity.
     */
    private fun navigateToMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }
}
