package com.example.language

import android.os.Bundle
import android.widget.CheckBox
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

/**
 * SCREEN 12: BookingQuotationActivity
 * ============================================================================
 * Calculates subtotal, multi-booking discount tier, and total quotation.
 * ============================================================================
 */
class BookingQuotationActivity : AppCompatActivity() {

    private val packagePrice = 1500.0
    private val activityPrice = 750.0

    private lateinit var cbPkgUltimate: CheckBox
    private lateinit var cbPkgFamily: CheckBox
    private lateinit var cbPkgMountain: CheckBox
    private lateinit var cbPkgCorporate: CheckBox

    private lateinit var cbActZiplining: CheckBox
    private lateinit var cbActKayaking: CheckBox
    private lateinit var cbActRock: CheckBox

    private lateinit var tvSubtotal: TextView
    private lateinit var tvDiscount: TextView
    private lateinit var tvTotalQuote: TextView

    private lateinit var etCustomerName: TextInputEditText
    private lateinit var etCustomerContact: TextInputEditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_booking_quotation)

        val root = findViewById<android.view.View>(R.id.booking_root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        cbPkgUltimate = findViewById(R.id.cb_pkg_ultimate)
        cbPkgFamily = findViewById(R.id.cb_pkg_family)
        cbPkgMountain = findViewById(R.id.cb_pkg_mountain)
        cbPkgCorporate = findViewById(R.id.cb_pkg_corporate)

        cbActZiplining = findViewById(R.id.cb_act_ziplining)
        cbActKayaking = findViewById(R.id.cb_act_kayaking)
        cbActRock = findViewById(R.id.cb_act_rock)

        tvSubtotal = findViewById(R.id.tv_subtotal)
        tvDiscount = findViewById(R.id.tv_discount)
        tvTotalQuote = findViewById(R.id.tv_total_quote)

        etCustomerName = findViewById(R.id.et_customer_name)
        etCustomerContact = findViewById(R.id.et_customer_contact)

        val checkBoxes = listOf(
            cbPkgUltimate, cbPkgFamily, cbPkgMountain, cbPkgCorporate,
            cbActZiplining, cbActKayaking, cbActRock
        )

        checkBoxes.forEach { cb ->
            cb.setOnCheckedChangeListener { _, _ ->
                calculateQuotation()
            }
        }

        findViewById<MaterialButton>(R.id.btn_submit_booking)?.setOnClickListener {
            submitBookingRequest()
        }

        calculateQuotation()
    }

    private fun calculateQuotation() {
        var count = 0
        var subtotal = 0.0

        if (cbPkgUltimate.isChecked) { count++; subtotal += packagePrice }
        if (cbPkgFamily.isChecked) { count++; subtotal += packagePrice }
        if (cbPkgMountain.isChecked) { count++; subtotal += packagePrice }
        if (cbPkgCorporate.isChecked) { count++; subtotal += packagePrice }

        if (cbActZiplining.isChecked) { count++; subtotal += activityPrice }
        if (cbActKayaking.isChecked) { count++; subtotal += activityPrice }
        if (cbActRock.isChecked) { count++; subtotal += activityPrice }

        val discountPercent = when {
            count >= 4 -> 15
            count == 3 -> 10
            count == 2 -> 5
            else -> 0
        }

        val discountAmount = subtotal * (discountPercent / 100.0)
        val finalTotal = subtotal - discountAmount

        tvSubtotal.text = String.format("Subtotal: R%.2f", subtotal)
        tvDiscount.text = String.format("Discount (%d%%): R%.2f", discountPercent, discountAmount)
        tvTotalQuote.text = String.format("Total Quotation: R%.2f", finalTotal)
    }

    private fun submitBookingRequest() {
        val name = etCustomerName.text?.toString()?.trim() ?: ""
        val contact = etCustomerContact.text?.toString()?.trim() ?: ""

        if (name.isEmpty() || contact.isEmpty()) {
            Toast.makeText(this, "Please enter your name and contact details.", Toast.LENGTH_SHORT).show()
            return
        }

        AlertDialog.Builder(this)
            .setTitle("Booking Request Sent!")
            .setMessage("Thank you, $name!\nYour booking quotation request has been submitted to Adventure Escape SA.")
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
                finish()
            }
            .show()
    }
}
