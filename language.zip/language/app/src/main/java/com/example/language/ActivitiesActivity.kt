package com.example.language

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.card.MaterialCardView
import com.google.android.material.button.MaterialButton

/**
 * SCREEN 4: ActivitiesActivity
 * ============================================================================
 * Overview screen displaying all 3 Individual Activities.
 * ============================================================================
 */
class ActivitiesActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_activities)

        val root = findViewById<android.view.View>(R.id.activities_root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Card 1 -> Screen 9
        findViewById<MaterialCardView>(R.id.card_act_ziplining)?.setOnClickListener {
            startActivity(Intent(this, ZipliningDetailActivity::class.java))
        }

        // Card 2 -> Screen 10
        findViewById<MaterialCardView>(R.id.card_act_kayaking)?.setOnClickListener {
            startActivity(Intent(this, KayakingDetailActivity::class.java))
        }

        // Card 3 -> Screen 11
        findViewById<MaterialCardView>(R.id.card_act_rock)?.setOnClickListener {
            startActivity(Intent(this, RockClimbingDetailActivity::class.java))
        }

        // Button -> Screen 12
        findViewById<MaterialButton>(R.id.btn_act_to_booking)?.setOnClickListener {
            startActivity(Intent(this, BookingQuotationActivity::class.java))
        }
    }
}
