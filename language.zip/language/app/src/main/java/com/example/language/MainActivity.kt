package com.example.language

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton

/**
 * SCREEN 2: MainActivity (Home Screen)
 * ============================================================================
 * Primary Home screen providing overview and navigation to Packages,
 * Activities, and Booking Quotation calculator.
 * ============================================================================
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Screen 3: Packages Navigation
        findViewById<MaterialButton>(R.id.btn_nav_packages)?.setOnClickListener {
            startActivity(Intent(this, PackagesActivity::class.java))
        }

        // Screen 4: Activities Navigation
        findViewById<MaterialButton>(R.id.btn_nav_activities)?.setOnClickListener {
            startActivity(Intent(this, ActivitiesActivity::class.java))
        }

        // Screen 12: Booking & Quotation Navigation
        findViewById<MaterialButton>(R.id.btn_nav_booking)?.setOnClickListener {
            startActivity(Intent(this, BookingQuotationActivity::class.java))
        }
    }
}

