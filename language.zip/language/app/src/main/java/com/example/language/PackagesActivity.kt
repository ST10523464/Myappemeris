package com.example.language

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.card.MaterialCardView
import com.google.android.material.button.MaterialButton

/**
 * SCREEN 3: PackagesActivity
 * ============================================================================
 * Overview screen displaying all 4 Adventure Packages.
 * ============================================================================
 */
class PackagesActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_packages)

        val root = findViewById<android.view.View>(R.id.packages_root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Card 1 -> Screen 5
        findViewById<MaterialCardView>(R.id.card_pkg_ultimate)?.setOnClickListener {
            startActivity(Intent(this, UltimateAdventureActivity::class.java))
        }

        // Card 2 -> Screen 6
        findViewById<MaterialCardView>(R.id.card_pkg_family)?.setOnClickListener {
            startActivity(Intent(this, FamilyExplorerActivity::class.java))
        }

        // Card 3 -> Screen 7
        findViewById<MaterialCardView>(R.id.card_pkg_mountain)?.setOnClickListener {
            startActivity(Intent(this, MountainAdventureActivity::class.java))
        }

        // Card 4 -> Screen 8
        findViewById<MaterialCardView>(R.id.card_pkg_corporate)?.setOnClickListener {
            startActivity(Intent(this, CorporateChallengeActivity::class.java))
        }

        // Button -> Screen 12
        findViewById<MaterialButton>(R.id.btn_to_booking)?.setOnClickListener {
            startActivity(Intent(this, BookingQuotationActivity::class.java))
        }
    }
}
