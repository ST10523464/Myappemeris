@echo off
echo ============================================================
echo   Adventure Escape SA - Push to GitHub Script
echo ============================================================
echo.

set /p REPO_URL="Enter your GitHub Repository URL (e.g., https://github.com/username/repo-name.git): "

if "%REPO_URL%"=="" (
    echo [ERROR] No URL provided. Exiting...
    pause
    exit /b
)

echo.
echo [1/5] Initializing Git repository...
git init

echo.
echo [2/5] Staging files...
git add .

echo.
echo [3/5] Creating initial commit...
git commit -m "Initial commit: Adventure Escape SA Android app with 12 screens"

echo.
echo [4/5] Setting default branch to main...
git branch -M main

echo.
echo [5/5] Adding remote and pushing to GitHub...
git remote add origin %REPO_URL%
git push -u origin main

echo.
echo ============================================================
echo   Push complete! Your project is now live on GitHub.
echo ============================================================
pause
